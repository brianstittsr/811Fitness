import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  { path: 'register', loadChildren: './register/register.module#RegisterPageModule' },
  { path: 'profile', loadChildren: './profile/profile.module#ProfilePageModule' },
  { path: 'fitness-baseline', loadChildren: './fitness-baseline/fitness-baseline.module#FitnessBaselinePageModule' },
  { path: 'main', loadChildren: './main/main.module#MainPageModule' },
  { path: 'day1', loadChildren: './day1/day1.module#Day1PageModule' },
  { path: 'day2', loadChildren: './day2/day2.module#Day2PageModule' },
  { path: 'day3', loadChildren: './day3/day3.module#Day3PageModule' },
  { path: 'day4', loadChildren: './day4/day4.module#Day4PageModule' },
  { path: 'day5', loadChildren: './day5/day5.module#Day5PageModule' },
  { path: 'day6', loadChildren: './day6/day6.module#Day6PageModule' },
  { path: 'day7', loadChildren: './day7/day7.module#Day7PageModule' },
  { path: 'dcategory', loadChildren: './dcategory/dcategory.module#DcategoryPageModule' },
  { path: 'details', loadChildren: './details/details.module#DetailsPageModule' },
  { path: 'diets', loadChildren: './diets/diets.module#DietsPageModule' },
  { path: 'elevels', loadChildren: './elevels/elevels.module#ElevelsPageModule' },
  { path: 'equipments', loadChildren: './equipments/equipments.module#EquipmentsPageModule' },
  { path: 'exercises', loadChildren: './exercises/exercises.module#ExercisesPageModule' },
  { path: 'favorites', loadChildren: './favorites/favorites.module#FavoritesPageModule' },
  { path: 'forget', loadChildren: './forget/forget.module#ForgetPageModule' },
  { path: 'goals', loadChildren: './goals/goals.module#GoalsPageModule' },
  { path: 'account', loadChildren: './account/account.module#AccountPageModule' },
  { path: 'blog', loadChildren: './blog/blog.module#BlogPageModule' },
  { path: 'bodyparts', loadChildren: './bodyparts/bodyparts.module#BodypartsPageModule' },
  { path: 'contact', loadChildren: './contact/contact.module#ContactPageModule' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
