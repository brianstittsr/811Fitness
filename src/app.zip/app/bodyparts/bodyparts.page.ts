import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bodyparts',
  templateUrl: './bodyparts.page.html',
  styleUrls: ['./bodyparts.page.scss'],
})
export class BodypartsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
