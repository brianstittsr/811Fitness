import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day2',
  templateUrl: './day2.page.html',
  styleUrls: ['./day2.page.scss'],
})
export class Day2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
