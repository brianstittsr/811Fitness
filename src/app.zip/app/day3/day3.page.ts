import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day3',
  templateUrl: './day3.page.html',
  styleUrls: ['./day3.page.scss'],
})
export class Day3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
