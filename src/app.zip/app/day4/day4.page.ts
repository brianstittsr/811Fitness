import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day4',
  templateUrl: './day4.page.html',
  styleUrls: ['./day4.page.scss'],
})
export class Day4Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
