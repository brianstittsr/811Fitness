import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day5',
  templateUrl: './day5.page.html',
  styleUrls: ['./day5.page.scss'],
})
export class Day5Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
