import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Day6Page } from './day6.page';

describe('Day6Page', () => {
  let component: Day6Page;
  let fixture: ComponentFixture<Day6Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Day6Page ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Day6Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
