import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day6',
  templateUrl: './day6.page.html',
  styleUrls: ['./day6.page.scss'],
})
export class Day6Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
