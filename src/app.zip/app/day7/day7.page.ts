import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day7',
  templateUrl: './day7.page.html',
  styleUrls: ['./day7.page.scss'],
})
export class Day7Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
