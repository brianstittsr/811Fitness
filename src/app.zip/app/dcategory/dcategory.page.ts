import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dcategory',
  templateUrl: './dcategory.page.html',
  styleUrls: ['./dcategory.page.scss'],
})
export class DcategoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
