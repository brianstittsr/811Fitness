import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elevels',
  templateUrl: './elevels.page.html',
  styleUrls: ['./elevels.page.scss'],
})
export class ElevelsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
