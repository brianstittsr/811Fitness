import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fitness-baseline',
  templateUrl: './fitness-baseline.page.html',
  styleUrls: ['./fitness-baseline.page.scss'],
})
export class FitnessBaselinePage implements OnInit {
  time_12hr: number;
  time_AMPM: string;
  maxweight_pushpress: number;
  maxweight_chestpress: number;
  maxweight_squat: number;  
  maxweight_deadlift: number;  
  treadmill_maxspeed_400meter: number;  
  treadmill_timecompleted_400meter: number;  
  treadmill_maxspeed_sprint: number;
  treadmill_timecompleted_sprint: number;
  maxreps_pushups: number;
  maxreps_situps: number;
  maxreps_lunges: number;
  maxtime_plank_seconds: number;


  constructor() { }

  ngOnInit() {
  }

}
